﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MOD_2_ASS_MHMD_AHMD_SYD_MHMD
{

    class Program
    {

        static bool IsValidBinary(string binaryString)
        {
            foreach (char c in binaryString)
            {
                if (c != '0' && c != '1')
                {
                    return false;
                }
            }
            return true;
        }
       static bool IsValidBinaryreg(string binaryString)
        {
            string pattern = @"^[01]+$";
            return Regex.IsMatch(binaryString, pattern);
        }
        static void Main(string[] args)
        {
            try
            {
                /*  q1 :
             1. do a program that reads an integer and checks 
             if it can be divided into two equal even numbers.
             */
                Console.WriteLine();
                Console.WriteLine("<<<<<< First Program >>>>>>");
                Console.Write("Enter Number : ");
                double checknum = Convert.ToDouble(Console.ReadLine());
                double dividednum = checknum / 2;
                //Console.WriteLine(dividednum);
                if (dividednum % 2 == 0)
                {
                    Console.WriteLine("--Output-- : ");
                    Console.WriteLine("YES");

                }
                else
                {
                    Console.WriteLine("--Output-- : ");
                    Console.WriteLine("NO");
                }

                /*  q2 :
                2) Read an integer number n,and print all odd numbers
                form 1 to n,using while loop. Enter a number :
                */
                Console.WriteLine();
                Console.WriteLine("<<<<<< Second Program >>>>>>");
                Console.Write("Enter Number : ");
                int N = Convert.ToInt32(Console.ReadLine());
                int loopcount = 1;
                Console.WriteLine("--Output-- : ");
                while (loopcount <= N)
                {
                    if (loopcount % 2 != 0)
                    {
                        if (loopcount == N) { Console.WriteLine(loopcount); break; }
                        Console.Write(loopcount + ",");
                    }
                    loopcount++;
                }
                Console.WriteLine();

                /*  q3 :
               2) Read an integer number n,and print all odd numbers
               form 1 to n,using while loop. Enter a number :
               */
                Console.WriteLine();
                Console.WriteLine("<<<<<< Third Program >>>>>>");
                Console.WriteLine("--Output-- : ");
                Console.WriteLine("_the first way_");

                for (int i = 1; i <= 25; i++)
                {
                    if (
                        i == 5
                        ) Console.WriteLine('*');
                    if (
                        i == 9 ||
                        i == 13 ||
                        i == 17 ||
                        i == 21) Console.Write('*');
                    if (
                       i == 1 ||
                       i == 2 ||
                       i == 3 ||
                       i == 4 ||
                       i == 6 ||
                       i == 7 ||
                       i == 8 ||
                       i == 11 ||
                       i == 12 ||
                       i == 16
                       ) Console.Write('*');
                    if (
                       i == 10 ||
                       i == 15 ||
                       i == 20 ||
                       i == 25) Console.WriteLine(' ');
                    if (
                        i == 14 ||
                        i == 18 ||
                        i == 19 ||
                        i == 22 ||
                        i == 23 ||
                        i == 24
                        ) Console.Write(' ');
                }
                Console.WriteLine("_the second way_");
                for (int i = 5; i > 0; i--)
                {
                    for (int x = 0; x < i; x++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("_the third way_");
                for (int i = 0; i < 5; i++)
                {
                    for (int x = 5; x > i; x--)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }

                /*  q4 :
              Read a binary number that consist of 4 digits, 
              then print the number of zero and the number of one.
              */
                Console.WriteLine();
                Console.WriteLine("<<<<<< Fourth Program >>>>>>");
                string varcheck1or0;
                int countnum0 = 0;
                int countnum1 = 0;
                bool test = false;
          
                do
                {
                    Console.Write("Enter Four Numbers : ");
                    varcheck1or0 = Console.ReadLine();
                    if (varcheck1or0.Length != 4 /*|| !IsValidBinary(varcheck1or0)*/ || !IsValidBinaryreg(varcheck1or0))
                        //(varcheck1or0[0] != '0' && varcheck1or0[0] != '1') ||
                        //(varcheck1or0[1] != '0' && varcheck1or0[1] != '1') ||
                        //(varcheck1or0[2] != '0' && varcheck1or0[2] != '1') ||
                        //(varcheck1or0[3] != '0' && varcheck1or0[3] != '1'))
                    {
                        test = true;
                    }
                    else
                    {
                        test = false;
                        for (int i = 0; i < 4; i++)
                        {
                            if (varcheck1or0[i] == '0') { countnum0++; }
                            if (varcheck1or0[i] == '1') { countnum1++; }
                        }
                    }
                } while (test);
                Console.WriteLine("The Number of 0 :" + countnum0);
                Console.WriteLine("The Number of 1 :" + countnum1);


                //this code to stop whole run
                Console.ReadKey();
            }
            catch (Exception)
            {
                Console.WriteLine("error please make every thing is right");
                Console.ReadKey();
                return;
            }

            
        }
    }
}
