﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace websheet5
{
    class Program
    {
        static void Main(string[] args)
        {
            int nm;
            float xcv;
            Console.Write("Enter the n  value =: ");
            nm = int.Parse(Console.ReadLine());
            Console.Write("Enter the x value =: ");
            xcv = int.Parse(Console.ReadLine());
            float sumnew = 1, term = 1;
            int iop = 1;
            while (iop < nm)
            {
                term *= iop / xcv;
                sumnew += term;
                iop++;
            }
            Console.WriteLine("the of all n  terms is  "+sumnew);






            int inputnxn = Convert.ToInt32(Console.ReadLine());
            double[,] nxnarray = new double[inputnxn,inputnxn];
            for (int inputarray = 0; inputarray < inputnxn; inputarray++)
            {
                for (int inputarray2 = 0; inputarray2 < inputnxn; inputarray2++)
                {

                    Console.Write($" nxnarray[{inputarray},{inputarray2}]");
                    nxnarray[inputarray,inputarray2]= Convert.ToDouble(Console.ReadLine());
                }
            }
            double sum = 0;
            for(int index  = 0; index < inputnxn; index++)
            {
                for(int index2 = 0; index2 < inputnxn; index2++)
                {
                    if(nxnarray[index,index2] <= 0)
                    {
                        Console.WriteLine("noyt markov");break;
                    }
                    sum += nxnarray[index2, index]; 
                }
                if(sum != 1)
                {
                    Console.WriteLine("noyt markov"); break;
                }
                else Console.WriteLine(" markov");
            }
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++");
            int numberx= Convert.ToInt32(Console.ReadLine());
            int numbern = Convert.ToInt32(Console.ReadLine());
            double fac;
            double calc = 1;
            for(int yu = 0; yu <= numbern; yu++)
            {
                numberx *= numberx;
                fac = 1;
                for (int numfac = 2; numfac <= numbern; numfac++) fac *= numfac;
                calc += fac / Math.Pow(numberx,yu);  
            }
            Console.WriteLine(calc);
            int m, b = 0;
            int[] binary = new int[8];
            Console.Write("Enter the decimal  number n =: ");
            m = int.Parse(Console.ReadLine());
            while (m > 0)
            {
                binary[b] = m % 2;
                m = m / 2;
                b++;
            }
            Console.Write("The binary  equivelant: ");
            for (int j = binary.Length - 1; j >= 0; j--)
                Console.Write(binary[j]);
            Console.WriteLine();
            // Define the original array
            int[][] X = new int[][] {
            new int[] { 1, 2, 3 },
            new int[] { 4, 5, 6 },
            new int[] { 7, 8, 9 }
        };
            int rows = X.Length;
            int cols = X[0].Length;
            int[][] Y = new int[3][] {
                new int[cols],
                 new int[cols],
            new int[cols]
            };
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Y[j][i] = X[i][j];
                }
            }
            Console.WriteLine("Original Array:");
            for (int i = 0; i < Y.Length; i++)
            {
                for (int j = 0; j < Y[i].Length; j++)
                {
                    Console.Write($"the array : {Y[i][j]} ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\nTranspose Array:");
            PrintArray(Y);




            Console.WriteLine();
            // Input decimal number
            Console.Write("Enter a decimal number: ");
            int decimalNumber = int.Parse(Console.ReadLine());

            // Check if number is within 8-bit range
            if (decimalNumber < 0 || decimalNumber > 255)
            {
                Console.WriteLine("Number must be between 0 and 255.");
                return;
            }

            // Convert decimal to binary string
            string binaryString = Convert.ToString(decimalNumber, 2);
            Console.WriteLine(binaryString);
            // Pad with leading zeros to 8 bits
            binaryString = binaryString.PadLeft(8, '0');

            // Print the binary representation
            Console.WriteLine("Binary representation: {0}", binaryString);

            Console.WriteLine("==============");
            double[,] matrix = new double[,] {
            { 0.4, 0.3, 0.3 },
            { 0.2, 0.5, 0.3 },
            { 0.4, 0.2, 0.4 }
        };

            bool isMarkovMatrix = IsPositiveMarkovMatrix(matrix);

            if (isMarkovMatrix)
            {
                Console.WriteLine("The matrix is a positive Markov matrix.");
            }
            else
            {
                Console.WriteLine("The matrix is not a positive Markov matrix.");
            }

            Console.WriteLine();
            int[] vector = { 5, 10, 3, 8, 15 };
            int largestValue = vector[0];

            for (int i = 1; i < vector.Length; i++)
            {
                if (vector[i] > largestValue)
                {
                    largestValue = vector[i];
                }
            }
            Console.WriteLine(vector + " " + largestValue);

            Console.WriteLine("The largest value in the vector is: {0}", largestValue);
            int[] vector1 = { 5, 10, 3, 8, 15 };
            int largestValue1 = vector.Max();
            Console.WriteLine(vector1 + " " + largestValue1);

            Console.WriteLine();
            Console.WriteLine();
            // Get input from the user
            Console.Write("Enter the value of n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Enter the value of x: ");
            double x = double.Parse(Console.ReadLine());

            // Calculate the sum
            double sum1 = 1;
            double factorial = 1;
            for (int i = 1; i <= nm; i++)
            {
                factorial = 1;
                for (int u = 2; u<= nm;u++){
            factorial *= u;
            }

            sum1 += factorial / Math.Pow(xcv, i);
            }

            // Print the result
            Console.WriteLine("The sum of the series is: {0}", sumnew);
            Console.ReadKey();
        }
        static void PrintArray(int[][] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 0; j < array[i].Length; j++)
                {
                    Console.Write($"{array[i][j]} ");
                }
                Console.WriteLine();
            }
        }





        static bool IsPositiveMarkovMatrix(double[,] matrix)
        {
            // Check for square matrix
            if (matrix.GetLength(0) != matrix.GetLength(1))
            {
                return false;
            }

            // Check for positive elements
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] <= 0)
                    {
                        return false;
                    }
                }
            }

            // Check for column sums equal to 1
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                double columnSum = 0;
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    columnSum += matrix[i, j];
                }
                if (Math.Abs(columnSum - 1) > double.Epsilon)
                {
                    return false;
                }
            }

            // All conditions met, return true
            return true;
        }


        // Sample matrix (positive Markov matrix)




    }

}

